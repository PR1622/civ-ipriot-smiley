import time
from sense_hat import SenseHat

# === Base Smiley Class ===
class Smiley:
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLUE = (0, 0, 255)
    YELLOW = (255, 255, 0)
    BLANK = (0, 0, 0)

    def __init__(self, complexion=YELLOW):
        self.sense_hat = SenseHat()
        self.my_complexion = complexion

        X = self.my_complexion
        O = self.BLANK
        self.pixels = [
            O, X, X, X, X, X, X, O,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            O, X, X, X, X, X, X, O,
        ]

    def complexion(self):
        return self.my_complexion

    def show(self):
        self.sense_hat.set_pixels(self.pixels)


# === Happy Smiley (Yellow) ===
class Happy(Smiley):
    def __init__(self, complexion=Smiley.YELLOW):
        super().__init__(complexion=complexion)
        self.draw_mouth()
        self.draw_eyes()

    def draw_mouth(self):
        mouth = [41, 46, 50, 51, 52, 53]
        for pixel in mouth:
            self.pixels[pixel] = self.BLANK

    def draw_eyes(self, wide_open=True):
        eyes = [10, 13, 18, 21]
        for pixel in eyes:
            self.pixels[pixel] = self.BLANK if wide_open else self.complexion()


# === Sad Smiley (Blue) ===
class Sad(Smiley):
    def __init__(self):
        super().__init__(complexion=self.BLUE)
        self.draw_mouth()
        self.draw_eyes()

    def draw_mouth(self):
        mouth = [49, 54, 42, 43, 44, 45]
        for pixel in mouth:
            self.pixels[pixel] = self.BLANK

    def draw_eyes(self, wide_open=True):
        eyes = [10, 13, 18, 21]
        for pixel in eyes:
            self.pixels[pixel] = self.BLANK if wide_open else self.complexion()


# === MAIN TESTER ===
if __name__ == "__main__":
    print("Showing Happy (Yellow)...")
    happy = Happy()
    happy.show()
    time.sleep(2)

    print("Showing Sad (Blue)...")
    sad = Sad()
    sad.show()
    time.sleep(2)

    print("Done!")
