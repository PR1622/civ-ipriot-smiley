class Happy(Smiley):
    def __init__(self, complexion=Smiley.YELLOW):
        super().__init__(complexion=complexion)
        self.draw_mouth()
        self.draw_eyes()
if __name__ == "__main__":
    happy_face = Happy()  # Should be yellow
    happy_face.show()
    time.sleep(1)

    sad_face = Sad()      # Should be blue
    sad_face.show()
    time.sleep(1)