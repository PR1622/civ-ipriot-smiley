import time
from sense_hat import SenseHat

# === Base Smiley Class ===
class Smiley:
    RED = (255, 0, 0)
    BLANK = (0, 0, 0)

    def __init__(self, complexion=RED):
        self.sense_hat = SenseHat()
        self.my_complexion = complexion

        X = self.my_complexion  # Face color
        O = self.BLANK          # Background
        self.pixels = [
            O, X, X, X, X, X, X, O,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            X, X, X, X, X, X, X, X,
            O, X, X, X, X, X, X, O,
        ]

    def complexion(self):
        return self.my_complexion

    def show(self):
        self.sense_hat.set_pixels(self.pixels)


# === Angry Smiley Subclass ===
class Angry(Smiley):
    def __init__(self):
        super().__init__(complexion=self.RED)  # Set complexion to red
        self.draw_mouth()
        self.draw_eyes()

    def draw_mouth(self):
        # Flat or frowning mouth for angry expression
        mouth = [40, 41, 42, 43, 44, 45]
        for pixel in mouth:
            self.pixels[pixel] = self.BLANK

    def draw_eyes(self, wide_open=True):
        # Eyes with an angry tilt
        eyes = [9, 12, 18, 21]
        for pixel in eyes:
            self.pixels[pixel] = self.BLANK if wide_open else self.complexion()

    def blink(self, delay=0.25):
        self.draw_eyes(wide_open=False)
        self.show()
        time.sleep(delay)
        self.draw_eyes(wide_open=True)
        self.show()


# === Run Angry Smiley ===
if __name__ == "__main__":
    angry = Angry()
    angry.show()
    time.sleep(1)
    angry.blink()
